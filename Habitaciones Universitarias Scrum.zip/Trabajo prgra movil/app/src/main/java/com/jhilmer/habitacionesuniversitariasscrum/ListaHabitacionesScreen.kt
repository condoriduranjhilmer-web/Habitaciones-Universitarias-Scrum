package com.jhilmer.habitacionesuniversitariasscrum

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

/**
 * Pantalla de Lista de Habitaciones - Sprint 2 (Firestore)
 * Tarea 4: Leer los cuartos directamente desde Firebase.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListaHabitacionesScreen(
    habitaciones: List<Habitacion>, 
    onHabitacionClick: (Habitacion) -> Unit,
    onPublicarClick: () -> Unit // Nueva navegación para publicar
) {
    var textoBusqueda by remember { mutableStateOf("") }
    var itemSeleccionado by remember { mutableIntStateOf(0) }
    
    var mostrarFiltros by remember { mutableStateOf(false) }
    var precioMaximo by remember { mutableFloatStateOf(1000f) }
    var zonaSeleccionada by remember { mutableStateOf("Todas") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Alquileres Universitarios", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { mostrarFiltros = !mostrarFiltros }) {
                        Icon(imageVector = if (mostrarFiltros) Icons.Default.Close else Icons.Default.FilterList, contentDescription = "Filtros", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF6200EE), titleContentColor = Color.White)
            )
        },
        floatingActionButton = {
            // Tarea 5: Botón para publicar un cuarto nuevo
            FloatingActionButton(onClick = onPublicarClick, containerColor = Color(0xFF6200EE)) {
                Icon(Icons.Default.Add, contentDescription = "Publicar", tint = Color.White)
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(selected = itemSeleccionado == 0, onClick = { itemSeleccionado = 0 }, icon = { Icon(Icons.Default.Home, contentDescription = "Inicio") }, label = { Text("Inicio") })
                NavigationBarItem(selected = itemSeleccionado == 1, onClick = { itemSeleccionado = 1 }, icon = { Icon(Icons.Default.Star, contentDescription = "Favoritos") }, label = { Text("Favoritos") })
                NavigationBarItem(selected = itemSeleccionado == 2, onClick = { itemSeleccionado = 2 }, icon = { Icon(Icons.Default.Person, contentDescription = "Perfil") }, label = { Text("Perfil") })
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = textoBusqueda,
                onValueChange = { textoBusqueda = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("¿Qué buscas hoy?") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Buscar") },
                shape = RoundedCornerShape(12.dp)
            )

            if (mostrarFiltros) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0E6FF)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Precio Máximo: ${precioMaximo.toInt()} Bs", fontWeight = FontWeight.Bold)
                        Slider(value = precioMaximo, onValueChange = { precioMaximo = it }, valueRange = 0f..1000f, colors = SliderDefaults.colors(thumbColor = Color(0xFF6200EE), activeTrackColor = Color(0xFF6200EE)))
                        Text("Zona:", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Todas", "Central", "Norte", "Sur").forEach { zona ->
                                FilterChip(selected = zonaSeleccionada == zona, onClick = { zonaSeleccionada = zona }, label = { Text(zona) })
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("Resultados en la Nube:", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val habitacionesFiltradas = habitaciones.filter { hab ->
                    val precioInt = hab.precio.filter { it.isDigit() }.toIntOrNull() ?: 0
                    val coincidePrecio = precioInt <= precioMaximo
                    val coincideZona = zonaSeleccionada == "Todas" || hab.ubicacion.contains(zonaSeleccionada, ignoreCase = true)
                    val coincideBusqueda = hab.titulo.contains(textoBusqueda, ignoreCase = true) || hab.ubicacion.contains(textoBusqueda, ignoreCase = true)
                    coincidePrecio && coincideZona && coincideBusqueda
                }
                
                items(habitacionesFiltradas) { hab ->
                    CardHabitacion(habitacion = hab, onClick = { onHabitacionClick(hab) })
                }
            }
        }
    }
}

@Composable
fun CardHabitacion(habitacion: Habitacion, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
    ) {
        Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AsyncImage(model = habitacion.imagenUrl, contentDescription = null, modifier = Modifier.size(80.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
            Column(modifier = Modifier.weight(1f)) {
                Text(text = habitacion.titulo, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF333333))
                Text(text = habitacion.ubicacion, color = Color.Gray, fontSize = 14.sp)
                Text(text = habitacion.precio, color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}
