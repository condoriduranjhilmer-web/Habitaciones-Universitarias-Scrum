package com.jhilmer.habitacionesuniversitariasscrum

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.auth.FirebaseAuth
import com.cloudinary.android.MediaManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicialización ultra estable
        try {
            MediaManager.init(this)
        } catch (e: Exception) {}

        setContent {
            // Quitamos el tema personalizado para asegurar que cargue
            Box(modifier = Modifier.fillMaxSize().background(Color.White)) {
                MainNavigation()
            }
        }
    }
}

@Composable
fun MainNavigation() {
    var pantallaActual by remember { mutableStateOf("splash") }
    var habitacionSeleccionada by remember { mutableStateOf<Habitacion?>(null) }
    
    when (pantallaActual) {
        "splash" -> SplashScreen(onTimeout = { 
            val user = FirebaseAuth.getInstance().currentUser
            pantallaActual = if (user != null) "lista" else "login" 
        })
        
        "login" -> LoginScreen(onLoginSuccess = {
            pantallaActual = "lista"
        })
        
        "lista" -> {
            val habViewModel: HabitacionesViewModel = viewModel()
            ListaHabitacionesScreen(
                habitaciones = habViewModel.habitaciones,
                onHabitacionClick = { hab ->
                    habitacionSeleccionada = hab
                    pantallaActual = "detalle"
                },
                onPublicarClick = {
                    pantallaActual = "publicar"
                }
            )
        }
        
        "detalle" -> habitacionSeleccionada?.let { hab ->
            DetalleHabitacionScreen(
                habitacion = hab,
                onBack = { pantallaActual = "lista" }
            )
        }
        
        "publicar" -> {
            val habViewModel: HabitacionesViewModel = viewModel()
            PublicarHabitacionScreen(
                viewModel = habViewModel,
                onBack = { pantallaActual = "lista" }
            )
        }
    }
}
