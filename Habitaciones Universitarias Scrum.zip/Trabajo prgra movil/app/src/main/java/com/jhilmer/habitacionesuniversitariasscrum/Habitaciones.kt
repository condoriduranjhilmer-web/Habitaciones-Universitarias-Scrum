package com.jhilmer.habitacionesuniversitariasscrum

/**
 * Modelo de datos para Firestore - Sprint 2
 */
data class Habitacion(
    val id: String = "",
    val titulo: String = "",
    val precio: String = "",
    val ubicacion: String = "",
    val descripcion: String = "",
    val servicios: String = "",
    val imagenUrl: String = "",
    val telefonoContacto: String = ""
)
