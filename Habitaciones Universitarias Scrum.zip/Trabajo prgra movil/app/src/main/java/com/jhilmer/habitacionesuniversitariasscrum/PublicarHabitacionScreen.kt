package com.jhilmer.habitacionesuniversitariasscrum

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cloudinary.android.MediaManager
import com.cloudinary.android.callback.ErrorInfo
import com.cloudinary.android.callback.UploadCallback

/**
 * Pantalla de Publicación de Cuartos - Sprint 2 (Final - Fotos)
 * Tareas cumplidas:
 * 1. Investigación: SDK Cloudinary y Galería.
 * 2. Diseño: Botón de "Agregar Imagen" y vista previa.
 * 3. Desarrollo: Selección, subida a Cloudinary y guardado.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublicarHabitacionScreen(viewModel: HabitacionesViewModel, onBack: () -> Unit) {
    var titulo by remember { mutableStateOf("") }
    var precio by remember { mutableStateOf("") }
    var ubicacion by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var servicios by remember { mutableStateOf("") }
    var imagenUrl by remember { mutableStateOf("") }
    var telefono by remember { mutableStateOf("") }
    
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var subiendoImagen by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        imageUri = uri
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Publicar Habitación") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Atrás", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF6200EE), titleContentColor = Color.White)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Tarea 3: Botón de Imagen y Vista Previa
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.LightGray)
                    .clickable { galleryLauncher.launch("image/*") },
                contentAlignment = Alignment.Center
            ) {
                if (imageUri != null) {
                    AsyncImage(
                        model = imageUri,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                        Text("Añadir Foto", color = Color.Gray)
                    }
                }
                
                if (subiendoImagen) {
                    CircularProgressIndicator(color = Color(0xFF6200EE))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(value = titulo, onValueChange = { titulo = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = precio, onValueChange = { precio = it }, label = { Text("Precio (ej: 450 Bs)") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = ubicacion, onValueChange = { ubicacion = it }, label = { Text("Ubicación/Zona") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = descripcion, onValueChange = { descripcion = it }, label = { Text("Descripción") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = servicios, onValueChange = { servicios = it }, label = { Text("Servicios") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(value = telefono, onValueChange = { telefono = it }, label = { Text("Teléfono de Contacto") }, modifier = Modifier.fillMaxWidth())
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Button(
                onClick = {
                    if (titulo.isNotEmpty() && precio.isNotEmpty() && imageUri != null) {
                        subiendoImagen = true
                        
                        // Tarea 4: Subida a Cloudinary
                        MediaManager.get().upload(imageUri)
                            .unsigned("TU_UPLOAD_PRESET") // <--- REEMPLAZAR
                            .callback(object : UploadCallback {
                                override fun onStart(requestId: String) {}
                                override fun onProgress(requestId: String, bytes: Long, totalBytes: Long) {}
                                override fun onSuccess(requestId: String, resultData: Map<*, *>) {
                                    val url = resultData["secure_url"].toString()
                                    val nuevaHab = Habitacion(
                                        titulo = titulo,
                                        precio = precio,
                                        ubicacion = ubicacion,
                                        descripcion = descripcion,
                                        servicios = servicios,
                                        imagenUrl = url,
                                        telefonoContacto = telefono
                                    )
                                    viewModel.publicarHabitacion(nuevaHab) { exito ->
                                        subiendoImagen = false
                                        if (exito) {
                                            Toast.makeText(context, "Publicado con éxito", Toast.LENGTH_SHORT).show()
                                            onBack()
                                        }
                                    }
                                }
                                override fun onError(requestId: String, error: ErrorInfo) {
                                    subiendoImagen = false
                                    Toast.makeText(context, "Error: ${error.description}", Toast.LENGTH_LONG).show()
                                }
                                override fun onReschedule(requestId: String, error: ErrorInfo) {}
                            }).dispatch()
                    } else {
                        Toast.makeText(context, "Faltan datos o imagen", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6200EE)),
                enabled = !subiendoImagen
            ) {
                if (subiendoImagen) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                else Text("Publicar Ahora", color = Color.White)
            }
        }
    }
}
