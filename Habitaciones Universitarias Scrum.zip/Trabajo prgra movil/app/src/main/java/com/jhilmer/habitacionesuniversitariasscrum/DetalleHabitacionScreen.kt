package com.jhilmer.habitacionesuniversitariasscrum

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

/**
 * Pantalla de Detalle de Habitación - SPRINT 3 (Fase Final)
 * 
 * Tareas cumplidas:
 * 1. INVESTIGACIÓN: Persistencia de estado booleano 'isFavorito'.
 * 2. CONFIGURACIÓN: Importación de iconos Favorite y FavoriteBorder.
 * 3. DISEÑO: Integración de botón de favoritos en la TopAppBar.
 * 4. DESARROLLO: Lógica de intercambio de estado (toggle) y mensajes Toast.
 * 5. PRUEBAS: Mejora de espaciados (Spacer debajo del Divider).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetalleHabitacionScreen(habitacion: Habitacion, onBack: () -> Unit) {
    val context = LocalContext.current
    
    // Tarea 1: Estado para controlar si es favorito
    var isFavorito by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detalles del Alquiler") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack, 
                            contentDescription = "Atrás", 
                            tint = Color.White
                        )
                    }
                },
                // Tarea 2 y 3: Botón de Favorito en la barra superior
                actions = {
                    IconButton(onClick = {
                        isFavorito = !isFavorito // Tarea 4: Alternar estado
                        
                        // Tarea 4: Mensaje de confirmación (Toast)
                        val mensaje = if (isFavorito) "Añadido a Favoritos" else "Eliminado de Favoritos"
                        Toast.makeText(context, mensaje, Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(
                            imageVector = if (isFavorito) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorito",
                            tint = if (isFavorito) Color.Red else Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF6200EE), 
                    titleContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Imagen desde Cloudinary (Sprint 2)
            AsyncImage(
                model = habitacion.imagenUrl,
                contentDescription = "Foto de la habitación",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(text = habitacion.titulo, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Precio: ${habitacion.precio}", 
                fontSize = 20.sp, 
                color = Color(0xFF4CAF50), 
                fontWeight = FontWeight.Bold
            )
            Text(text = "Ubicación: ${habitacion.ubicacion}", fontSize = 16.sp, color = Color.Gray)

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(thickness = 1.dp, color = Color.LightGray)
            
            // Tarea 5: Mejora visual - Spacer debajo de la línea divisoria
            Spacer(modifier = Modifier.height(16.dp))

            Text(text = "Descripción:", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(text = habitacion.descripcion, fontSize = 15.sp, color = Color(0xFF555555))
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(text = "Servicios Incluidos:", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(text = habitacion.servicios, fontSize = 15.sp, color = Color(0xFF555555))

            Spacer(modifier = Modifier.height(32.dp))

            // Botón de WhatsApp (Sprint 2)
            Button(
                onClick = {
                    val mensaje = "Hola, estoy interesado en la habitación: ${habitacion.titulo}"
                    val url = "https://api.whatsapp.com/send?phone=${habitacion.telefonoContacto}&text=${Uri.encode(mensaje)}"
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        data = Uri.parse(url)
                    }
                    context.startActivity(intent)
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6200EE)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Contactar al Dueño", fontSize = 16.sp, color = Color.White)
            }
        }
    }
}

@androidx.compose.ui.tooling.preview.Preview(showBackground = true, showSystemUi = true)
@Composable
fun DetalleHabitacionPreview() {
    MaterialTheme {
        val habitacionEjemplo = Habitacion(
            id = "1",
            titulo = "Habitación de Prueba",
            precio = "500 Bs",
            ubicacion = "Cerca de la Facultad",
            descripcion = "Descripción de prueba para el Sprint 3 con favoritos.",
            servicios = "Luz, Agua, Internet",
            imagenUrl = "https://res.cloudinary.com/demo/image/upload/sample.jpg",
            telefonoContacto = "59170000000"
        )
        DetalleHabitacionScreen(
            habitacion = habitacionEjemplo,
            onBack = {}
        )
    }
}
