package com.jhilmer.habitacionesuniversitariasscrum

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.toObject

class HabitacionesViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()
    private val _habitaciones = mutableStateListOf<Habitacion>()
    val habitaciones: List<Habitacion> get() = _habitaciones

    init {
        escucharHabitaciones()
    }

    private fun escucharHabitaciones() {
        // Tarea 4: Lectura de datos desde Firestore en tiempo real
        db.collection("habitaciones")
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                
                if (snapshot != null) {
                    _habitaciones.clear()
                    for (doc in snapshot.documents) {
                        val habitacion = doc.toObject<Habitacion>()?.copy(id = doc.id)
                        if (habitacion != null) {
                            _habitaciones.add(habitacion)
                        }
                    }
                }
            }
    }

    fun publicarHabitacion(habitacion: Habitacion, onComplete: (Boolean) -> Unit) {
        // Tarea 4: Escritura de datos en Firestore
        db.collection("habitaciones")
            .add(habitacion)
            .addOnCompleteListener { task ->
                onComplete(task.isSuccessful)
            }
    }
}
